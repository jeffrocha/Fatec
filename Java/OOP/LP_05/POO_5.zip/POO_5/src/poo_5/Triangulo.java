/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poo_5;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */
public class Triangulo {
    private double base;
    private double altura;

    public Triangulo() {
    }

    public void lerBaseAltura() {
        this.base = obterNumero("Digite o valor da base do triângulo:");
        this.altura = obterNumero("Digite o valor da altura do triângulo:");
    }

    public double calcularArea() {
        return (base * altura) / 2;
    }

    private double obterNumero(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número válido.");
            }
        }
    }
}
