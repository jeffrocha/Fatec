/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo_5;
import javax.swing.JOptionPane;

/**
 *
 * @author J&L
 */
public class Main {
    public static void main(String[] args) {

        Triangulo triangulo = new Triangulo();
        triangulo.lerBaseAltura();
        double areaTriangulo = triangulo.calcularArea();
        JOptionPane.showMessageDialog(null, "A área do triângulo é: " + areaTriangulo);

        Equacao equacao = new Equacao();
        equacao.lerValores();
        equacao.calcularRaizes();


        Pessoa einstein = new Pessoa("Albert Einstein", 14, 3, 1879);
        Pessoa newton = new Pessoa("Isaac Newton", 4, 1, 1643);


        int diaAtual = Integer.parseInt(JOptionPane.showInputDialog("Digite o dia atual:"));
        int mesAtual = Integer.parseInt(JOptionPane.showInputDialog("Digite o mês atual:"));
        int anoAtual = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano atual:"));

        einstein.calculaIdade(diaAtual, mesAtual, anoAtual);
        newton.calculaIdade(diaAtual, mesAtual, anoAtual);

        JOptionPane.showMessageDialog(null, "Idade de Einstein: " + einstein.informaIdade() +
                "\nIdade de Newton: " + newton.informaIdade());
    }
}

