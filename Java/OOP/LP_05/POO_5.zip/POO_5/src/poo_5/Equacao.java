/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo_5;
import javax.swing.JOptionPane;

/**
 *
 * @author J&L
 */
public class Equacao {
    private int a;
    private int b;
    private int c;

    public Equacao() {
        // Construtor vazio
    }

    public void lerValores() {
        this.a = obterInteiro("Digite o valor de A:");
        this.b = obterInteiro("Digite o valor de B:");
        this.c = obterInteiro("Digite o valor de C:");
    }

    public void calcularRaizes() {
        double delta = b * b - 4 * a * c;
        if (delta < 0) {
            JOptionPane.showMessageDialog(null, "Não existem raízes reais.");
        } else if (delta == 0) {
            double raiz = -b / (2.0 * a);
            JOptionPane.showMessageDialog(null, "As raízes são iguais: R1 = R2 = " + raiz);
        } else {
            double raizDelta = Math.sqrt(delta);
            double r1 = (-b + raizDelta) / (2.0 * a);
            double r2 = (-b - raizDelta) / (2.0 * a);
            JOptionPane.showMessageDialog(null, "As raízes são: R1 = " + r1 + " e R2 = " + r2);
        }
    }

    private int obterInteiro(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número inteiro válido.");
            }
        }
    }
}
