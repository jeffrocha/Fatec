/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */
public class EX_08 {
    public static void main(String[] args) {
        int varNum = funcObterNumero("Digite um número para verificar se é primo:");

        if (funcPrimoTrue(varNum)) {
            JOptionPane.showMessageDialog(null, "O número " + varNum + " é primo.");
        } else {
            JOptionPane.showMessageDialog(null, "O número " + varNum + " não é primo.");
        }
    }

    private static int funcObterNumero(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número válido.");
            }
        }
    }


    private static boolean funcPrimoTrue(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}
