/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */
public class EX_04 {
    public static void main(String[] args) {
        double varGrau = funcObterGrau("Digite o ângulo em graus:");
        double varRadiano = funcConvParaRadianos(varGrau);

        JOptionPane.showMessageDialog(null, "O ângulo de " + varGrau + " graus equivale a " + varRadiano + " radianos.");
    }

    private static double funcObterGrau(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um ângulo válido.");
            }
        }
    }

    private static double funcConvParaRadianos(double varGrau) {
        double pi = Math.PI;
        return varGrau * pi / 180;
    }
}
