/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */
public class EX_02 {
    public static void main(String[] args) {
        int varQtdVetor = 4;
        double[] vetorNotas = new double[varQtdVetor];
        for (int i = 0; i < varQtdVetor; i++) {
            vetorNotas[i] = funcObterNota("Digite a nota " + (i + 1) + ":");
        }
        double media = funcCalcularMedia(vetorNotas);
        JOptionPane.showMessageDialog(null, "A média aritmética é: " + media);
    }
    private static double funcObterNota(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                double nota = Double.parseDouble(input);
                if (nota < 0 || nota > 10) {
                    JOptionPane.showMessageDialog(null, "Por favor, digite uma nota válida (entre 0 e 10).");
                } else {
                    return nota;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite uma nota válida.");
            }
        }
    }
      private static double funcCalcularMedia(double[] vetorNotas) {
        double soma = 0;
        for (int i = 0; i < vetorNotas.length; i++) {
            soma += vetorNotas[i];
        }
        return soma / vetorNotas.length;
    }
}