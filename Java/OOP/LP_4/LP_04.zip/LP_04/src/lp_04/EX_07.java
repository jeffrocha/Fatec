/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
import java.math.BigInteger;
/**
 *
 * @author J&L
 */
public class EX_07 {
    public static void main(String[] args) {
        BigInteger varNum = funcObterNumero("Digite um número para calcular o fatorial:");
        BigInteger fatorial = funcCalcularFatorial(varNum);
        JOptionPane.showMessageDialog(null, "O fatorial de " + varNum + " é: " + fatorial);
    }
    
    private static BigInteger funcObterNumero(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                BigInteger varNum = new BigInteger(input);
                if (varNum.compareTo(BigInteger.ZERO) < 0) {
                    JOptionPane.showMessageDialog(null, "Por favor, digite um número positivo.");
                } else {
                    return varNum;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número válido.");
            }
        }
    }

    private static BigInteger funcCalcularFatorial(BigInteger varNum) {
        if (varNum.compareTo(BigInteger.ZERO) < 0) {
            throw new IllegalArgumentException("O fatorial não está definido para números negativos.");
        }
        BigInteger fatorial = BigInteger.ONE;
        for (BigInteger i = BigInteger.ONE; i.compareTo(varNum) <= 0; i = i.add(BigInteger.ONE)) {
            fatorial = fatorial.multiply(i);
        }
        return fatorial;
    }
}
