/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */

public class EX_01 {
    public static void main(String[] args) {
        int numero = FuncObterNumero("Digite um número inteiro:");
        int dobro = FuncDobrar(numero);
        JOptionPane.showMessageDialog(null, "O dobro de " + numero + " é: " + dobro);
    }

      private static int FuncObterNumero(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                int numero = Integer.parseInt(input);
                if (numero % 1 == 0) {
                    return numero;
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, digite um número inteiro válido.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número inteiro válido.");
            }
        }
    }

    private static int FuncDobrar(int numero) {
        return numero * 2;
    }
}