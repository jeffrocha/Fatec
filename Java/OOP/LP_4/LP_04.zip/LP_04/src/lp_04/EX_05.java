/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */
public class EX_05 {
    public static void main(String[] args) {
        double varNum1 = obterNumero("Digite o primeiro número:");
        double varNum2 = obterNumero("Digite o segundo número:");
        funcEncontrarMaior(varNum1, varNum2);
    }

    private static double obterNumero(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número válido.");
            }
        }
    }

    private static void funcEncontrarMaior(double varNum1, double varNum2) {
        if (varNum1 > varNum2) {
            JOptionPane.showMessageDialog(null, "O maior número é: " + varNum1);
        } else if (varNum2 > varNum1) {
            JOptionPane.showMessageDialog(null, "O maior número é: " + varNum2);
        } else {
            JOptionPane.showMessageDialog(null, "Os números são iguais.");
        }
    }
}