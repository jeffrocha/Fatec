/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */
public class EX_03 {
    public static void main(String[] args) {
        double varValor1 = funcObterValor("Digite o primeiro valor:");
        double varValor2 = funcObterValor("Digite o segundo valor:");
        double varProduto = FuncTirarProduto(varValor1, varValor2);
        JOptionPane.showMessageDialog(null, "O produto dos valores é: " + varProduto);
    }

    private static double funcObterValor(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um valor válido.");
            }
        }
    }
    
    private static double FuncTirarProduto(double valor1, double valor2) {
        return valor1 * valor2;
    }
}
