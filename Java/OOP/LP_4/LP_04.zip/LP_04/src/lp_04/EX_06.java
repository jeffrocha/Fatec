/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lp_04;
import javax.swing.JOptionPane;
/**
 *
 * @author J&L
 */
public class EX_06 {
    public static void main(String[] args) {
        int varNumMes = funObterNumMes("Digite um número correspondente ao primeiro trimestre:");
        funcMostrarMes(varNumMes);
    }

    private static int funObterNumMes(String mensagem) {
        while (true) {
            try {
                String input = JOptionPane.showInputDialog(mensagem);
                if (input == null) {
                    JOptionPane.showMessageDialog(null, "Programa encerrado.");
                    System.exit(0);
                }
                int numero = Integer.parseInt(input);
                if (numero >= 1 && numero <= 3) {
                    return numero;
                } else {
                    JOptionPane.showMessageDialog(null, "Número inválido. Digite um número de 1 a 3.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, digite um número válido.");
            }
        }
    }

    private static void funcMostrarMes(int varNumMes) {
        switch (varNumMes) {
            case 1:
                JOptionPane.showMessageDialog(null, "O mês correspondente ao número 1 é Janeiro.");
                break;
            case 2:
                JOptionPane.showMessageDialog(null, "O mês correspondente ao número 2 é Fevereiro.");
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "O mês correspondente ao número 3 é Março.");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Número inválido. Digite um número de 1 a 3.");
        }
    }
}
